# Integrating into your existing Yasmin project

I could not see your source files. Map of what to replace or merge:

| Your file | This project | Action |
|---|---|---|
| YasminAccessibilityService.kt | screen/YasminAccessibilityService.kt + ScreenReader.kt | Merge: keep your other logic; add `instance`, `readActiveScreen()`, the minimal `onAccessibilityEvent`. Add ScreenReader.kt. |
| accessibility_service_config.xml | res/xml/accessibility_service_config.xml | Ensure `canRetrieveWindowContent=true`, `flagReportViewIds`, `flagRetrieveInteractiveWindows`, window state/content events. |
| ScreenCaptureManager.kt | screen/ScreenCaptureManager.kt | Replace (one-shot, blank-frame detection). |
| MediaProjectionService.kt | screen/MediaProjectionService.kt | Replace; needs `foregroundServiceType="mediaProjection"` + `FOREGROUND_SERVICE_MEDIA_PROJECTION`. |
| VisionViewModel.kt / VisionFragment.kt | vision/* | Replace or merge the state machine; keep the Analyze button wired to `manualAnalyze()`. |
| MainActivity.kt | MainActivity.kt | Only needs to host the fragment (+ notification permission). |
| AndroidManifest.xml | AndroidManifest.xml | Merge services, permissions, `<queries>`. |
| CommandRouter.kt | CommandRouter.kt (complete file) + screen/ScreenCommandParser.kt | Replace, or call `CommandRouter.route(text, vm)` first and continue with your handlers when it returns `NotHandled`. |
| YasminVoiceRuntime.kt | voice/YasminVoiceRuntime.kt | **Keep yours.** Call your speak function from `Event.Speak`. Mine is a minimal stand-in. |

Your existing Gemini/Groq clients can replace `ai/AiClients.kt`; keep `ModelSelection` + `PromptBuilder`, and keep the rule: call providers only from `onTextConsent`/`onImageConsent`.
Package name is `com.yasmin.ai`; adjust if yours differs.

package com.yasmin.ai

import com.yasmin.ai.screen.ScreenCommandParser
import com.yasmin.ai.screen.ScreenIntent
import com.yasmin.ai.screen.TargetApp
import org.junit.Assert.*
import org.junit.Test

class ScreenCommandParserTest {
    private fun p(s: String) = ScreenCommandParser.parse(s)

    @Test fun readCommands() {
        listOf(
            "Read my screen", "Screen padho", "What is on my screen?", "What's on my screen",
            "Read the text", "Read the current app"
        ).forEach { assertEquals(it, ScreenIntent.READ, p(it)?.intent) }
    }

    @Test fun targetedReads() {
        assertEquals(TargetApp.CHATGPT, p("ChatGPT ki screen padho.")?.target)
        assertEquals(TargetApp.CHATGPT, p("ChatGPT screen read karo")?.target)
        assertEquals(ScreenIntent.READ, p("ChatGPT ne kya answer diya?")?.intent)
        assertEquals(TargetApp.CHATGPT, p("ChatGPT ne kya answer diya?")?.target)
        assertEquals(ScreenIntent.READ, p("ChatGPT ka text Yasmin ko dikhao.")?.intent)
        assertEquals(TargetApp.YOUTUBE, p("Read YouTube screen")?.target)
        assertEquals(TargetApp.CHROME, p("Read Chrome screen")?.target)
    }

    @Test fun hindiExplain() {
        val c = p("Is answer ko Hindi mein samjhao.")!!
        assertEquals(ScreenIntent.EXPLAIN, c.intent)
        assertEquals("hi", c.responseLanguage)
        assertTrue(c.referencesPrevious)
    }

    @Test fun summaries() {
        assertEquals(ScreenIntent.SUMMARIZE, p("ChatGPT ke answer ka summary banao.")?.intent)
        assertEquals(TargetApp.CHATGPT, p("ChatGPT ke answer ka summary banao.")?.target)
        assertEquals(ScreenIntent.SUMMARIZE, p("Summarize visible content")?.intent)
    }

    @Test fun explainPage() = assertEquals(ScreenIntent.EXPLAIN, p("Explain this page")?.intent)

    @Test fun screenshot() = assertEquals(ScreenIntent.VISION_ANALYZE, p("analyze my screenshot")?.intent)

    @Test fun nonScreenCommandsFallThrough() {
        listOf("play some music", "open youtube", "read my messages", "what is the weather", "call mom", "").forEach {
            assertNull("should not match: $it", p(it))
        }
    }
}

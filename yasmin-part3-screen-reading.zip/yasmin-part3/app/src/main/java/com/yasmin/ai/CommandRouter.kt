package com.yasmin.ai

import com.yasmin.ai.screen.ScreenCommandParser
import com.yasmin.ai.vision.VisionViewModel

/**
 * Complete router for this project. Screen-reading commands are handled here;
 * anything else returns NotHandled so other Yasmin handlers (music, calls, etc.) can run.
 */
object CommandRouter {

    sealed class RouteResult {
        object ScreenCommandStarted : RouteResult()
        object NotHandled : RouteResult()
    }

    fun route(text: String, vision: VisionViewModel, delayMs: Long = 0): RouteResult {
        val screenCommand = ScreenCommandParser.parse(text) ?: return RouteResult.NotHandled
        vision.runCommand(screenCommand, delayMs)
        return RouteResult.ScreenCommandStarted
    }
}

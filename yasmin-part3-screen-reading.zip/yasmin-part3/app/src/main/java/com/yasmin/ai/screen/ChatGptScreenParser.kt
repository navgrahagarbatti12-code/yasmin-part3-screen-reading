package com.yasmin.ai.screen

// Pure Kotlin. Works on a generic ScreenSnapshot: it does NOT assume a fixed ChatGPT view tree.

enum class MessageRole { USER, ASSISTANT, UNKNOWN }

data class ChatMessage(val order: Int, val role: MessageRole, val text: String, val evidence: String?)

data class ChatParseResult(
    val messages: List<ChatMessage>,
    val rolesIdentified: Boolean,
    val note: String
) {
    /** Conversation view for user review. */
    fun toReviewText(): String = messages.joinToString("\n\n") { m ->
        val label = when (m.role) {
            MessageRole.USER -> "You"
            MessageRole.ASSISTANT -> "ChatGPT"
            MessageRole.UNKNOWN -> "Unlabelled"
        }
        "[$label]\n${m.text}"
    }

    /** Text sent to the AI provider ONLY after the user approves it. */
    fun toPromptText(): String = toReviewText()
}

object ChatGptScreenParser {
    val KNOWN_PACKAGES = setOf("com.openai.chatgpt")

    /** Dynamic detection: known package OR the resolved app label says ChatGPT. */
    fun isChatGpt(packageName: String?, appLabel: String?): Boolean =
        (packageName != null && packageName in KNOWN_PACKAGES) ||
            (appLabel?.contains("chatgpt", ignoreCase = true) == true)

    private val userPrefix = Regex("""^\s*(you said|you|user)\s*[:：-]\s*""", RegexOption.IGNORE_CASE)
    private val assistantPrefix = Regex("""^\s*(chatgpt said|chatgpt|assistant)\s*[:：-]\s*""", RegexOption.IGNORE_CASE)
    private val userId = Regex("""(^|[_./:])(user|human|prompt|outgoing)([_.]|$)""", RegexOption.IGNORE_CASE)
    private val assistantId = Regex("""(^|[_./:])(assistant|bot|chatgpt|response|incoming|answer)([_.]|$)""", RegexOption.IGNORE_CASE)

    private fun words(s: String) = s.trim().split(Regex("\\s+")).count { it.isNotEmpty() }

    fun parse(snapshot: ScreenSnapshot): ChatParseResult {
        val raw = ArrayList<ChatMessage>()
        for (e in snapshot.elements) {
            if (e.kind != ElementKind.TEXT) continue                      // composer / inputs are not messages
            val w = words(e.text)
            if (e.clickable && w <= 4) continue                            // short buttons (Copy, Share, Retry…)
            if (e.isHeading && w <= 4) continue                            // app/model title
            val (role, evidence, cleaned) = detectRole(e)
            raw += ChatMessage(e.order, role, cleaned, evidence)
        }
        // Merge adjacent blocks only when both carry the SAME explicit role evidence
        val merged = ArrayList<ChatMessage>()
        for (m in raw) {
            val last = merged.lastOrNull()
            if (last != null && last.role != MessageRole.UNKNOWN && last.role == m.role) {
                merged[merged.size - 1] = last.copy(text = last.text + "\n" + m.text)
            } else merged += m
        }
        val identified = merged.any { it.role != MessageRole.UNKNOWN }
        val note = when {
            merged.isEmpty() -> "No message-like text was exposed by the ChatGPT screen."
            identified -> "Roles were assigned only where the UI exposed explicit labels or IDs; other blocks are marked Unlabelled."
            else -> "The UI did not expose enough evidence to tell your messages from ChatGPT's. All blocks are shown in visible order without roles."
        }
        return ChatParseResult(merged, identified, note)
    }

    private data class Detected(val role: MessageRole, val evidence: String?, val text: String)

    private fun detectRole(e: ScreenElement): Detected {
        val desc = e.description.orEmpty()
        userPrefix.find(e.text)?.let { return Detected(MessageRole.USER, "text prefix", e.text.removeRange(it.range)) }
        assistantPrefix.find(e.text)?.let { return Detected(MessageRole.ASSISTANT, "text prefix", e.text.removeRange(it.range)) }
        if (userPrefix.containsMatchIn(desc)) return Detected(MessageRole.USER, "content description", e.text)
        if (assistantPrefix.containsMatchIn(desc)) return Detected(MessageRole.ASSISTANT, "content description", e.text)
        val id = e.viewId.orEmpty()
        if (id.isNotEmpty()) {
            val u = userId.containsMatchIn(id)
            val a = assistantId.containsMatchIn(id)
            if (u && !a) return Detected(MessageRole.USER, "view id", e.text)
            if (a && !u) return Detected(MessageRole.ASSISTANT, "view id", e.text)
        }
        // Deliberately NOT inferring from left/right alignment: that is a guess, not evidence.
        return Detected(MessageRole.UNKNOWN, null, e.text)
    }
}

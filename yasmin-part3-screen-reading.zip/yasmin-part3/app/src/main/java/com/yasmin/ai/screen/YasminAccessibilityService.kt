package com.yasmin.ai.screen

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

enum class ReadStatus { OK, OK_EMPTY, NO_ACTIVE_WINDOW, OWN_APP }

data class ServiceReadOutcome(val snapshot: ScreenSnapshot?, val status: ReadStatus, val reason: String? = null)

/**
 * Event handling is intentionally minimal: we remember ONLY the time of the last window change
 * (to know when the UI has settled). No event text, no node content, no package history is stored.
 * Screen content is read only when [readActiveScreen] is called after a user request.
 */
class YasminAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: YasminAccessibilityService? = null
            private set

        fun status(context: Context): AccessibilityStatus {
            if (instance != null) return AccessibilityStatus.CONNECTED
            val enabled = Settings.Secure.getString(
                context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return AccessibilityStatus.NOT_ENABLED
            val cn = ComponentName(context, YasminAccessibilityService::class.java)
            val match = enabled.split(':').any {
                it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
            }
            return if (match) AccessibilityStatus.ENABLED_NOT_CONNECTED else AccessibilityStatus.NOT_ENABLED
        }
    }

    private val reader = ScreenReader()
    @Volatile private var lastChangeUptime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> lastChangeUptime = SystemClock.uptimeMillis()
            else -> Unit
        }
    }

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /**
     * User-initiated read of the active window.
     * Waits for the UI to settle, retries on null root / empty tree (delayed UI updates),
     * and always recycles the root node.
     */
    suspend fun readActiveScreen(
        ownPackage: String,
        maxWaitMs: Long = 3000,
        settleMs: Long = 350
    ): ServiceReadOutcome = withContext(Dispatchers.Default) {
        val deadline = SystemClock.uptimeMillis() + maxWaitMs
        while (true) {
            while (SystemClock.uptimeMillis() - lastChangeUptime < settleMs && SystemClock.uptimeMillis() < deadline) {
                delay(60)
            }
            val root = acquireRoot()
            if (root == null) {
                if (SystemClock.uptimeMillis() >= deadline) {
                    return@withContext ServiceReadOutcome(
                        null, ReadStatus.NO_ACTIVE_WINDOW,
                        "Android did not expose an active window (screen locked, secure screen, or transition in progress)."
                    )
                }
                delay(250)
                continue
            }
            try {
                val pkg = root.packageName?.toString().orEmpty()
                if (pkg == ownPackage) {
                    return@withContext ServiceReadOutcome(null, ReadStatus.OWN_APP, "Yasmin itself is in the foreground.")
                }
                val snapshot = reader.read(root, labelFor(pkg))
                val timedOut = SystemClock.uptimeMillis() >= deadline
                if (snapshot.elements.isNotEmpty() || timedOut) {
                    return@withContext ServiceReadOutcome(
                        snapshot, if (snapshot.elements.isEmpty()) ReadStatus.OK_EMPTY else ReadStatus.OK
                    )
                }
            } finally {
                recycleNode(root)
            }
            delay(300)
        }
        // Unreachable (loop only exits via return); keeps the lambda's type as ServiceReadOutcome.
        ServiceReadOutcome(null, ReadStatus.NO_ACTIVE_WINDOW)
    }

    private fun acquireRoot(): AccessibilityNodeInfo? {
        val active = try { rootInActiveWindow } catch (_: Exception) { null }
        if (active != null) return active
        // Fallback: pick an active/focused application window from the interactive-windows list.
        val list = try { windows } catch (_: Exception) { emptyList<AccessibilityWindowInfo>() }
        var chosen: AccessibilityNodeInfo? = null
        for (w in list) {
            try {
                if (chosen == null && w.type == AccessibilityWindowInfo.TYPE_APPLICATION && (w.isActive || w.isFocused)) {
                    chosen = w.root
                }
            } catch (_: Exception) {
            } finally {
                recycleWindow(w)
            }
        }
        return chosen
    }

    private fun labelFor(pkg: String): String? = try {
        val ai = packageManager.getApplicationInfo(pkg, 0)
        packageManager.getApplicationLabel(ai).toString()
    } catch (_: Exception) { null }   // not visible to us / not installed: caller falls back to package name

    @Suppress("DEPRECATION")
    private fun recycleNode(n: AccessibilityNodeInfo) { try { n.recycle() } catch (_: Exception) {} }

    @Suppress("DEPRECATION")
    private fun recycleWindow(w: AccessibilityWindowInfo) { try { w.recycle() } catch (_: Exception) {} }
}

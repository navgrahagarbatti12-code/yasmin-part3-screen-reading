package com.yasmin.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Minimal TextToSpeech stand-in so this project builds on its own.
 * In your real app keep YOUR YasminVoiceRuntime and just call its speak function from the Speak event.
 */
class YasminVoiceRuntime(context: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var queued: Pair<String, String?>? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            queued?.let { if (ready) speak(it.first, it.second) }
            queued = null
        }
    }

    fun speak(text: String, languageTag: String? = null) {
        val engine = tts
        if (engine == null || !ready) { queued = text to languageTag; return }
        engine.stop()
        val locale = languageTag?.let { Locale.forLanguageTag(it) } ?: Locale.getDefault()
        val r = engine.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.getDefault())     // voice data missing: fall back, don't fail silently
        }
        chunk(text, 3500).forEachIndexed { i, part ->
            engine.speak(part, TextToSpeech.QUEUE_ADD, null, "yasmin-$i")
        }
    }

    fun stop() { tts?.stop() }
    fun shutdown() { tts?.shutdown(); tts = null; ready = false }

    private fun chunk(text: String, max: Int): List<String> {
        if (text.length <= max) return listOf(text)
        val out = ArrayList<String>()
        var rest = text
        while (rest.length > max) {
            val cut = rest.lastIndexOfAny(charArrayOf('\n', '.', '।', '?', '!'), max).let { if (it < max / 2) max else it + 1 }
            out += rest.substring(0, cut)
            rest = rest.substring(cut)
        }
        if (rest.isNotBlank()) out += rest
        return out
    }
}

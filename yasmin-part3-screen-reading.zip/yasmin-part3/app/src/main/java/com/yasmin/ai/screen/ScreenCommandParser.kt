package com.yasmin.ai.screen

// Pure Kotlin. Returns null when the utterance is not a screen-reading command,
// so CommandRouter can fall through to its other handlers.

enum class ScreenIntent { READ, EXPLAIN, SUMMARIZE, VISION_ANALYZE }

enum class TargetApp(val displayName: String, val packages: Set<String>, val labelHints: List<String>) {
    CHATGPT("ChatGPT", setOf("com.openai.chatgpt"), listOf("chatgpt")),
    YOUTUBE("YouTube", setOf("com.google.android.youtube"), listOf("youtube")),
    CHROME("Chrome", setOf("com.android.chrome"), listOf("chrome")),
    SETTINGS("Settings", setOf("com.android.settings"), listOf("settings"));

    fun matches(packageName: String?, appLabel: String?): Boolean =
        (packageName != null && packageName in packages) ||
            labelHints.any { appLabel?.contains(it, ignoreCase = true) == true }
}

data class ScreenCommand(
    val intent: ScreenIntent,
    val target: TargetApp? = null,
    /** "hi" when the user asked for Hindi output; null = same language as the question. */
    val responseLanguage: String? = null,
    /** "Is answer ko…" / "explain this answer": reuse the last reviewed read instead of re-reading. */
    val referencesPrevious: Boolean = false,
    val rawText: String = ""
)

object ScreenCommandParser {

    private fun normalize(s: String): String =
        s.lowercase().replace("'", "").replace("’", "")
            .replace(Regex("[^\\p{L}\\p{M}\\p{N}]+"), " ").trim()

    private fun detectTarget(t: String): TargetApp? = when {
        "chatgpt" in t || "chat gpt" in t || "चैटजीपीटी" in t -> TargetApp.CHATGPT
        "youtube" in t || "यूट्यूब" in t -> TargetApp.YOUTUBE
        "chrome" in t || "क्रोम" in t -> TargetApp.CHROME
        Regex("""\bsettings?\b""").containsMatchIn(t) -> TargetApp.SETTINGS
        else -> null
    }

    private val readVerb = Regex("""\b(read|padho|padh|padhna|dikhao|dikha|show|batao|bata)\b|पढ़ो|पढ़|दिखाओ|बताओ""")
    private val contentNoun = Regex("""\b(screen|text|app|content|page|answer|jawab)\b|स्क्रीन|टेक्स्ट""")
    private val hindi = Regex("""\bhindi\b|हिंदी|हिन्दी""")
    private val explainVerb = Regex("""\b(samjh\w*|samajh\w*|explain|bata\w*|translate|anuvad)\b|समझा""")
    private val summarize = Regex("""\b(summar\w*|saransh|sarans|khulasa)\b|सारांश""")
    private val prevRef = Regex("""\b(is answer|this answer|iska|isko|is ko|ye answer|yeh answer|is jawab)\b""")

    fun parse(raw: String): ScreenCommand? {
        val t = normalize(raw)
        if (t.isBlank()) return null
        val target = detectTarget(t)

        fun cmd(i: ScreenIntent, lang: String? = null, prev: Boolean = false) =
            ScreenCommand(i, target, lang, prev, raw)

        // 1) Screenshot / vision
        if ("screenshot" in t || "स्क्रीनशॉट" in t) return cmd(ScreenIntent.VISION_ANALYZE)

        val contentCue = contentNoun.containsMatchIn(t) || target != null || "visible" in t

        // 2) Hindi explanation ("Is answer ko Hindi mein samjhao")
        if (hindi.containsMatchIn(t) && explainVerb.containsMatchIn(t) && (contentCue || prevRef.containsMatchIn(t))) {
            return cmd(ScreenIntent.EXPLAIN, "hi", prevRef.containsMatchIn(t))
        }

        // 3) Summaries
        if (summarize.containsMatchIn(t) && contentCue) {
            return cmd(ScreenIntent.SUMMARIZE, if (hindi.containsMatchIn(t)) "hi" else null, prevRef.containsMatchIn(t))
        }

        // 4) Explain
        if (explainVerb.containsMatchIn(t) && contentCue &&
            (Regex("""\bexplain\b""").containsMatchIn(t) || Regex("""samjh|samajh|समझा""").containsMatchIn(t))
        ) {
            return cmd(ScreenIntent.EXPLAIN, null, prevRef.containsMatchIn(t))
        }

        // 5) Read
        if (Regex("""what(s| is) on my screen""").containsMatchIn(t) ||
            Regex("""(screen|स्क्रीन) (par|pe|mein|me) kya""").containsMatchIn(t) ||
            Regex("""kya (answer|jawab)""").containsMatchIn(t) ||
            Regex("""(answer|jawab) kya""").containsMatchIn(t)
        ) return cmd(ScreenIntent.READ)

        if (readVerb.containsMatchIn(t) && contentNoun.containsMatchIn(t)) return cmd(ScreenIntent.READ)
        if (readVerb.containsMatchIn(t) && target != null) return cmd(ScreenIntent.READ)

        return null
    }
}
